<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Loader extends Model
{
    //
}
