<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ErrorBanner extends Model
{
    //
}
